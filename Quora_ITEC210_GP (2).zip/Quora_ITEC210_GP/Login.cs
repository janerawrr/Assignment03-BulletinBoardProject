﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quora_ITEC210_GP
{
    public partial class Login : Form
    {
        public static string CurrentUser;
        public Login()
        {
            InitializeComponent();
            pictureBox1.Image = new Bitmap("Quora.png");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {

            for(int i = 0; i < User.ourUsersWithEmail.Count; i++)
            {
                for(int j = 0; j < User.UserPassword.Count; j++)
                {
                    if(User.UserPassword[j] == txtPass.Text && User.ourUsersWithEmail[i]== txtEmail.Text)
                    {
                        if(i==j)
                        {
                            CurrentUser = User.ourUsersName[i];
                           
                            this.Hide();
                            HomePage homePage = new HomePage();
                            homePage.ShowDialog();
                        }
                    }
                }
            }
           
        }
    }
}
