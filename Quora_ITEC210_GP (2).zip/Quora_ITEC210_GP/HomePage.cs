﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quora_ITEC210_GP
{
    public partial class HomePage : Form
    {
        public static string questions;
        public string comment = "";
        public bool showcomment;
       
        public HomePage()
        {
            InitializeComponent();
            timer1.Enabled = true;
            btnAnswer.BackgroundImage = new Bitmap("answer.png");
            btnASKS.BackgroundImage = new Bitmap("Ask.png");
            btnPOST.BackgroundImage= new Bitmap("Post.png");
            btnComm.BackgroundImage = new Bitmap("comment.png");
            btnDownvote.BackgroundImage = new Bitmap("downvote.png");
            btnUpvote.BackgroundImage = new Bitmap("upvote.png");
        }

        private void HomePage_Load(object sender, EventArgs e)
        {
            label1.Text = Login.CurrentUser;
            lblUser.Text = Login.CurrentUser;
            if (CreatePost_question.showpost)
            {
                groupBox1.Visible = true;   
                textBox1.Text = questions;
                lblCUser.Text = Login.CurrentUser;
               
            }
            if (Post.showpost)
            {
                groupBox1.Visible = true;
                textBox1.Text = questions;
                lblCUser.Text = Login.CurrentUser;

            }

            if (showcomment)
            {
                groupBox2.Visible = true;
                textBox3.Text = comment;
            }
          
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblUser_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            HomePage_Load(sender, e);
        }

        private void btnAsk_Click(object sender, EventArgs e)
        {
            
            CreatePost_question create = new CreatePost_question();
            create.ShowDialog();
        }

        private void btnASKS_Click(object sender, EventArgs e)
        {
            
            CreatePost_question create = new CreatePost_question();
            create.ShowDialog();
        }

        private void btnPOST_Click(object sender, EventArgs e)
        {
       
            Post post = new Post();
            post.ShowDialog();
        }

        private void btnAnswer_Click(object sender, EventArgs e)
        {
            Answer answer = new Answer();
            answer.ShowDialog();
        }

        private void btnComment_Click(object sender, EventArgs e)
        {
            comment = txtComment.Text;
            if (comment != null)
                showcomment = true;
        }

        private void btnUpvote_Click(object sender, EventArgs e)
        {
            lblVote.Text = "1";
        }

        private void btnDownvote_Click(object sender, EventArgs e)
        {
            lblVote.Text = "0";
        }

        private void lblVote_Click(object sender, EventArgs e)
        {

        }

        private void btnComm_Click(object sender, EventArgs e)
        {
            groupBox3.Visible = true;
        }

        private void btnComment_Click_1(object sender, EventArgs e)
        {
            comment = txtComment.Text;
            if (comment != null)
                showcomment = true;
        }
    }
}
