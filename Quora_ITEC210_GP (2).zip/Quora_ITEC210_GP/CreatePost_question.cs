﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quora_ITEC210_GP
{
    public partial class CreatePost_question : Form
    {
        public static bool showpost; 
        public CreatePost_question()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            HomePage.questions = textBox1.Text;
            if(HomePage.questions != null)
                showpost = true;
            
            this.Hide();
            
        }

        private void btnQuestion_Click(object sender, EventArgs e)
        {
          
        }

        private void btnPost_Click(object sender, EventArgs e)
        {
            this.Hide();
            Post post = new Post();
            post.ShowDialog();
        }
    }
}
