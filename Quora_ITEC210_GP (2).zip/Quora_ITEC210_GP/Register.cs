﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;

namespace Quora_ITEC210_GP
{
   
    public partial class Register : Form
    {
        User user;
        public Register()
        {
            InitializeComponent();
            pictureBox1.Image = new Bitmap("Quora.png");
        }

        private void Register_Load(object sender, EventArgs e)
        {

        }

        private void btnSignUP_Click(object sender, EventArgs e)
        {
            string username = txtName.Text;
            string useremail = txtEmail.Text;
            string userPass = txtPassword.Text;

            user = new User(username, useremail, userPass);

           
            this.Hide();
            Login login = new Login();
            login.ShowDialog();
        }
    }
}
