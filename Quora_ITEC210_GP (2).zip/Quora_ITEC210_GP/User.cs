﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quora_ITEC210_GP
{
    [Serializable()]
    public class User
    {
        public string Name { get; set; }
        public string email { get; set; }
        public string password { get; set; }    

        public static List<string> UserPassword= new List<string>();
        public static List<string> ourUsersWithEmail = new List<string>();
        public static List<string> ourUsersName = new List<string>();


        public User(string uname, string uemail, string upassword)
        {
            Name = uname;   
            email = uemail;
            password = upassword;
            UserPassword.Add(password);
            ourUsersWithEmail.Add(email);
            ourUsersName.Add(uname);
        }

    }
}
