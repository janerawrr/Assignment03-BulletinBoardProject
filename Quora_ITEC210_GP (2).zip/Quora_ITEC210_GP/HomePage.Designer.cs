﻿namespace Quora_ITEC210_GP
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAsk = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblVote = new System.Windows.Forms.Label();
            this.btnComm = new System.Windows.Forms.Button();
            this.btnDownvote = new System.Windows.Forms.Button();
            this.btnUpvote = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtComment = new System.Windows.Forms.TextBox();
            this.lblCuser2 = new System.Windows.Forms.Label();
            this.btnComment = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lblCUser = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnASKS = new System.Windows.Forms.Button();
            this.btnAnswer = new System.Windows.Forms.Button();
            this.btnPOST = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Emoji", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(104, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "User";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnAsk
            // 
            this.btnAsk.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAsk.Location = new System.Drawing.Point(267, 12);
            this.btnAsk.Name = "btnAsk";
            this.btnAsk.Size = new System.Drawing.Size(674, 71);
            this.btnAsk.TabIndex = 1;
            this.btnAsk.Text = "What do you want to ask or share ?";
            this.btnAsk.UseVisualStyleBackColor = true;
            this.btnAsk.Click += new System.EventHandler(this.btnAsk_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblVote);
            this.groupBox1.Controls.Add(this.btnComm);
            this.groupBox1.Controls.Add(this.btnDownvote);
            this.groupBox1.Controls.Add(this.btnUpvote);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.lblUser);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Location = new System.Drawing.Point(92, 164);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(927, 536);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Visible = false;
            // 
            // lblVote
            // 
            this.lblVote.AutoSize = true;
            this.lblVote.Location = new System.Drawing.Point(73, 252);
            this.lblVote.Name = "lblVote";
            this.lblVote.Size = new System.Drawing.Size(0, 20);
            this.lblVote.TabIndex = 10;
            this.lblVote.Click += new System.EventHandler(this.lblVote_Click);
            // 
            // btnComm
            // 
            this.btnComm.Location = new System.Drawing.Point(160, 242);
            this.btnComm.Name = "btnComm";
            this.btnComm.Size = new System.Drawing.Size(39, 40);
            this.btnComm.TabIndex = 9;
            this.btnComm.UseVisualStyleBackColor = true;
            this.btnComm.Click += new System.EventHandler(this.btnComm_Click);
            // 
            // btnDownvote
            // 
            this.btnDownvote.Location = new System.Drawing.Point(103, 242);
            this.btnDownvote.Name = "btnDownvote";
            this.btnDownvote.Size = new System.Drawing.Size(39, 40);
            this.btnDownvote.TabIndex = 9;
            this.btnDownvote.UseVisualStyleBackColor = true;
            this.btnDownvote.Click += new System.EventHandler(this.btnDownvote_Click);
            // 
            // btnUpvote
            // 
            this.btnUpvote.Location = new System.Drawing.Point(28, 242);
            this.btnUpvote.Name = "btnUpvote";
            this.btnUpvote.Size = new System.Drawing.Size(39, 40);
            this.btnUpvote.TabIndex = 9;
            this.btnUpvote.UseVisualStyleBackColor = true;
            this.btnUpvote.Click += new System.EventHandler(this.btnUpvote_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtComment);
            this.groupBox3.Controls.Add(this.lblCuser2);
            this.groupBox3.Controls.Add(this.btnComment);
            this.groupBox3.Location = new System.Drawing.Point(28, 288);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(842, 72);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            this.groupBox3.Visible = false;
            // 
            // txtComment
            // 
            this.txtComment.Location = new System.Drawing.Point(86, 19);
            this.txtComment.Name = "txtComment";
            this.txtComment.Size = new System.Drawing.Size(413, 27);
            this.txtComment.TabIndex = 10;
            // 
            // lblCuser2
            // 
            this.lblCuser2.AutoSize = true;
            this.lblCuser2.Location = new System.Drawing.Point(8, 22);
            this.lblCuser2.Name = "lblCuser2";
            this.lblCuser2.Size = new System.Drawing.Size(38, 20);
            this.lblCuser2.TabIndex = 9;
            this.lblCuser2.Text = "User";
            // 
            // btnComment
            // 
            this.btnComment.Location = new System.Drawing.Point(516, 20);
            this.btnComment.Name = "btnComment";
            this.btnComment.Size = new System.Drawing.Size(158, 26);
            this.btnComment.TabIndex = 8;
            this.btnComment.Text = "Add a Comment";
            this.btnComment.UseVisualStyleBackColor = true;
            this.btnComment.Click += new System.EventHandler(this.btnComment_Click_1);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.lblCUser);
            this.groupBox2.Location = new System.Drawing.Point(28, 366);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(840, 125);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Visible = false;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(6, 46);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(569, 67);
            this.textBox3.TabIndex = 1;
            // 
            // lblCUser
            // 
            this.lblCUser.AutoSize = true;
            this.lblCUser.Location = new System.Drawing.Point(6, 23);
            this.lblCUser.Name = "lblCUser";
            this.lblCUser.Size = new System.Drawing.Size(38, 20);
            this.lblCUser.TabIndex = 0;
            this.lblCUser.Text = "User";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(30, 34);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(42, 20);
            this.lblUser.TabIndex = 1;
            this.lblUser.Text = "User ";
            this.lblUser.Click += new System.EventHandler(this.lblUser_Click);
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(30, 47);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(840, 189);
            this.textBox1.TabIndex = 0;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnASKS
            // 
            this.btnASKS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnASKS.Location = new System.Drawing.Point(351, 89);
            this.btnASKS.Name = "btnASKS";
            this.btnASKS.Size = new System.Drawing.Size(125, 37);
            this.btnASKS.TabIndex = 3;
            this.btnASKS.UseVisualStyleBackColor = true;
            this.btnASKS.Click += new System.EventHandler(this.btnASKS_Click);
            // 
            // btnAnswer
            // 
            this.btnAnswer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAnswer.Location = new System.Drawing.Point(556, 89);
            this.btnAnswer.Name = "btnAnswer";
            this.btnAnswer.Size = new System.Drawing.Size(125, 37);
            this.btnAnswer.TabIndex = 3;
            this.btnAnswer.UseVisualStyleBackColor = true;
            this.btnAnswer.Click += new System.EventHandler(this.btnAnswer_Click);
            // 
            // btnPOST
            // 
            this.btnPOST.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPOST.Location = new System.Drawing.Point(753, 89);
            this.btnPOST.Name = "btnPOST";
            this.btnPOST.Size = new System.Drawing.Size(124, 31);
            this.btnPOST.TabIndex = 3;
            this.btnPOST.UseVisualStyleBackColor = true;
            this.btnPOST.Click += new System.EventHandler(this.btnPOST_Click);
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1190, 698);
            this.Controls.Add(this.btnPOST);
            this.Controls.Add(this.btnAnswer);
            this.Controls.Add(this.btnASKS);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnAsk);
            this.Controls.Add(this.label1);
            this.Name = "HomePage";
            this.Text = "HomePage";
            this.Load += new System.EventHandler(this.HomePage_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Button btnAsk;
        private GroupBox groupBox1;
        private Label lblUser;
        private TextBox textBox1;
        private System.Windows.Forms.Timer timer1;
        private Button btnASKS;
        private Button btnAnswer;
        private Button btnPOST;
        private GroupBox groupBox2;
        private Label lblCUser;
        private TextBox textBox3;
        private Label lblVote;
        private Button btnDownvote;
        private Button btnUpvote;
        private GroupBox groupBox3;
        private TextBox txtComment;
        private Label lblCuser2;
        private Button btnComment;
        private Button btnComm;
    }
}