﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quora_ITEC210_GP
{
    public partial class Answer : Form
    {
        public Answer()
        {
            InitializeComponent();
        }
    }
}
